from random import randint
from math import gcd


def gcd_game():
    number1 = randint(1, 100)
    number2 = randint(1, 100)
    numbers = f'{number1} {number2}'


    return numbers
